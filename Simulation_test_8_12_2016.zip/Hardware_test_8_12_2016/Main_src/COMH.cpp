#include "Project_Path.h"
#include RELATIVE_PATH(COMH.h)
#include RELATIVE_PATH(ERRH.h)
#include SIMULATION_PATH(SIMU.h)
#undef PROJECT_PATH_H


 /*values of directions*/
uint16 NORTH_VALUE = 0;
uint16 EAST_VALUE = 90;
uint16 SOUTH_VALUE = 180;
uint16 WEST_VALUE = 270;

Comp::Comp()
{
  //Put the HMC5883 IC into the correct operating mode
  Wire.beginTransmission(I2C_ADDRESS); //open communication with HMC5883
  Wire.write(0x02); //select mode register
  Wire.write(0x00); //continuous measurement mode
  Wire.endTransmission();
}

Comp& Comp::getInstance(void)
{
	static Comp compass;
	return compass;
}

void Comp::InitializeDirections(void)
{
  offset = Comp::ReadRawData();
}

uint16 Comp::ReadRawData(void)
{
	//triple axis data
	int16_t x = 0;
	int16_t y = 0;
	int16_t z = 0;

	float heading = 0;
	//Tell the HMC5883L where to begin reading data
	Wire.beginTransmission(I2C_ADDRESS);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission();
	
	//Read data from each axis, 2 registers per axis
	Wire.requestFrom(I2C_ADDRESS, 6);

	if(6<=Wire.available())
	{
		x = Wire.read()<<8; //X msb
		x |= Wire.read(); //X lsb
		z = Wire.read()<<8; //Z msb
		z |= Wire.read(); //Z lsb
		y = Wire.read()<<8; //Y msb
		y |= Wire.read(); //Y lsb
	}

	heading = atan2(y,x);

	heading *= CONVERT_FROM_RAD_TO_DEG;

	//offset to force North to be equal 0
	heading -= offset;

	if(heading < 0)
	{
		heading += 360;
	}

#undef FILTERED_COMPASS_READING
#ifdef FILTERED_COMPASS_READING
	tempAngle = Comp::compassKalmanFilter1D(tempAngle);
#endif
Serial.print("Temp Angle from Raw Data: ");
Serial.println(heading);
	return (uint16)(heading + 0.5);
}

#ifdef FILTERED_COMPASS_READING
#define PROCESS_NOISE 2.5
#define MEASUREMENTS_NOISE 1.2

uint16 Comp::compassKalmanFilter1D(uint16 Z)
{
	static uint16 X = 0;
	static uint16 P = 1000;
	static uint16 K = 0;

	if ((X > 350) && (Z < 10))
	{
		X = 0;
		K = 0;
		P = 1000;
	}

	P = P * PROCESS_NOISE;

	K = P / (P + MEASUREMENTS_NOISE);
	X = X + K * (Z - X);
	P = (1 - K) * P;

	return (uint16)(X);
}
#endif

Heading Comp::ReadComp(void)
{

  Heading Angle;
  uint16 tempAngle;

  tempAngle = ReadRawData();

  if(tempAngle < ALLOWED_ANGLE_ERROR)
  {
	  tempAngle = ALLOWED_ANGLE_ERROR;
  }

  if(NORTH_VALUE < ALLOWED_ANGLE_ERROR)
  {
	  NORTH_VALUE = ALLOWED_ANGLE_ERROR;
  }
  else if (WEST_VALUE < ALLOWED_ANGLE_ERROR)
  {
	  WEST_VALUE = ALLOWED_ANGLE_ERROR;
  }
  else if (SOUTH_VALUE < ALLOWED_ANGLE_ERROR)
  {
	  SOUTH_VALUE = ALLOWED_ANGLE_ERROR;
  }
  else if (EAST_VALUE < ALLOWED_ANGLE_ERROR)
  {
	  EAST_VALUE = ALLOWED_ANGLE_ERROR;
  }
  else
  {
	  /* do nothing */
  }



  if ((tempAngle > (NORTH_VALUE - ALLOWED_ANGLE_ERROR)) && (tempAngle < (NORTH_VALUE + ALLOWED_ANGLE_ERROR)))
  {
    Angle = NORTH;
  }
  else if ((tempAngle >(WEST_VALUE - ALLOWED_ANGLE_ERROR)) && (tempAngle < (WEST_VALUE + ALLOWED_ANGLE_ERROR)))
  {
    Angle = WEST;
  }
  else if ((tempAngle >(SOUTH_VALUE - ALLOWED_ANGLE_ERROR)) && (tempAngle < (SOUTH_VALUE + ALLOWED_ANGLE_ERROR)))
  {
    Angle = SOUTH;
  }
  else if ((tempAngle >(EAST_VALUE - ALLOWED_ANGLE_ERROR)) && (tempAngle < (EAST_VALUE + ALLOWED_ANGLE_ERROR)))
  {
    Angle = EAST;
  }
  else
  {
	  Serial.print("the compass reading: ");
	  Serial.println(tempAngle);
    /*TODO handling wrong calling while not being in 4 directions*/
    Angle = INVALID_DIRECTION;
	ERRH::Error_logErrorClass(ERROR_COMH_INVALID_HEADING);
  }
  return Angle;
}

return_type Comp::CheckConnection(void)
{
	return_type ret = RET_NOT_OK;
	uint16 TempAngle = UINT_SNA;
	uint16 CurrentAngle = UINT_SNA;

	TempAngle = Comp::ReadRawData();
	delay(COMPASS_CONNECTION_CHECK_DELAY_TIME);
	CurrentAngle = Comp::ReadRawData();

	if (TempAngle != CurrentAngle)
	{
		ret = RET_OK;
	}
	else
	{
		ERRH::Error_logErrorClass(ERROR_COMH_COMPASS_NC);
	}
	return ret;
}
