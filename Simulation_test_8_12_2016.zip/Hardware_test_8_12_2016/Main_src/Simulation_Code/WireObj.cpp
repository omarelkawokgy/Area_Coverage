#include "WireObj.h"
#include <iostream>
using namespace std;

/*----------------------------------------Wire---------------------------------*/
WireI2C Wire = WireI2C();

WireI2C::WireI2C(){}
WireI2C::~WireI2C(){}

void WireI2C::beginTransmission(int address)
{

}

void WireI2C::write(int numberOfRegister)
{

}

void WireI2C::endTransmission(void)
{

}

uint8 WireI2C::read()
{
	return 0;
}

void WireI2C::requestFrom(int address, const int reg)
{

}

uint8 WireI2C::available()
{
	return 6;
}