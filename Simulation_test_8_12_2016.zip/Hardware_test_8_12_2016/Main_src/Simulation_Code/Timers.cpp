#include "Timers.h"
#include <iostream>
using namespace std;

#include "UNO_GPIO.h"

/*-----------Time Functions--------------*/
void delay(int time)
{

}

void delayMicroseconds(int time)
{

}

uint64 millis(void)
{
	return 0;
}

uint64 pulseIn(uint8 pin, bool flag)
{
	uint64 timeDuration = 0;
	if ((gpio.DigitalULSLeftFlag == HIGH) || (gpio.DigitalULSRightFlag == HIGH))
	{
		timeDuration = CM_TO_MICRO_SECONDS(100);
	}
	return timeDuration;
}