#ifndef PINMODE_H
#define PINMODE_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

#define DIGITAL_GPIO_SIZE 14
#define ANALOG_GPIO_SIZE 6

class PinModeObj
{
private:
	uint8 pin;
	uint8 type;
	uint8 value;
public:
	PinModeObj();
	~PinModeObj();
	PinModeObj(uint8 _pin, uint8 _type, uint8 _value);
	uint8 getPin();
	uint8 getType();
	uint8 getValue();
	void setPin(uint8 _pin);
	void setType(uint8 _type);
	void setValue(uint8 _value);
};

extern PinModeObj digitalPinArray[DIGITAL_GPIO_SIZE];
extern PinModeObj analogPinArray[ANALOG_GPIO_SIZE];

void pinMode(uint8 _pin, uint8 TYPE);
#endif