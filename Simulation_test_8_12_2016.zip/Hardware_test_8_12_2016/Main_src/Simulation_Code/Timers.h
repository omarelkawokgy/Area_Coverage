#ifndef TIMERS_H
#define TIMERS_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

#define CM_TO_MICRO_SECONDS(X) (X * 29.4118 * 2)

/*-----------Time Functions--------------*/
void delay(int time);
void delayMicroseconds(int time);
uint64 millis(void);
uint64 pulseIn(uint8 pin, bool flag);
#endif 