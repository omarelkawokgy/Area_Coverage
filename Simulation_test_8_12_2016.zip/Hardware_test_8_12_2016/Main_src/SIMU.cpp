#include "Project_Path.h"
#include RELATIVE_PATH(SIMU.h)
#include RELATIVE_PATH(CONF.h)

#ifdef ENABLE_SIMULATION
#include <iostream>
using namespace std;

/*----------------------------------Serial--------------------------------*/
SerialCom Serial = SerialCom();

SerialCom::SerialCom(){}
SerialCom::~SerialCom(){}

void SerialCom::begin(int speed){}
void SerialCom::print(int number)
{
	cout << number;
}

void SerialCom::println(int number)
{
	cout << number << endl;
}

void SerialCom::print(int number, int type)
{
	if (type == HEX)
	{
		cout << hex << number;
	}
}

void SerialCom::println(int number, int type)
{
	if (type == HEX)
	{
		cout << hex << number << endl;
	}
}

void SerialCom::print(char* string)
{
	cout << string;
}

void SerialCom::println(char* string)
{
	cout << string << endl;
}

void SerialCom::println(void)
{
	cout << endl;
}

/*----------------------------------------Wire---------------------------------*/
WireI2C Wire = WireI2C();

WireI2C::WireI2C(){}
WireI2C::~WireI2C(){}

void WireI2C::beginTransmission(int address)
{

}

void WireI2C::write(int numberOfRegister)
{

}

void WireI2C::endTransmission(void)
{

}

uint8 WireI2C::read()
{
	return 0;
}

void WireI2C::requestFrom(int address, const int reg)
{

}

uint8 WireI2C::available()
{
	return 6;
}

/*----------------------------- Arduino Functions ------------------------*/
float atan2(uint16 y, uint16 x)
{
	return 0.61086;
}

/*-----------------GPIO------------------*/
void pinMode(uint8 pin, uint8 TYPE)
{

}

void digitalWrite(uint8 pin, bool flag)
{

}

uint32 pulseIn(uint8 pin, bool flag)
{
	return 300;
}

bool digitalRead(uint8 pin)
{
	return true;
}

void analogWrite(uint8 pin, uint8 PWM)
{

}

uint8 analogRead(uint8 pin)
{
	return 255;
}

/*--------------Interrupt-----------------*/
void attachInterrupt(uint8 numberOfInterrupt, void(*func)(), uint8 type)
{

}

/*-----------Time Functions--------------*/
void delay(int time)
{

}

void delayMicroseconds(int time)
{

}

uint64 millis(void)
{
	return 0;
}

#endif
