
#ifndef SIMU_H
#define SIMU_H

#include "types.h"
#include "CONF.h"
#ifdef ENABLE_SIMULATION
class simu
{
public:	
};

class SerialCom
{
public:
	SerialCom();
	~SerialCom();

	void begin(int speed);
	void print(int number);
	void println(int number);
	void print(char* string);
	void println(char* string);
	void print(int number, int type);
	void println(int number, int type);
	void println(void);
};
extern SerialCom Serial;

class WireI2C
{
public:
	WireI2C();
	~WireI2C();

	void beginTransmission(int address);
	void write(int numberOfRegister);
	void endTransmission(void);
	uint8 read();
	void requestFrom(int address, const int reg);
	uint8 available();
};
extern WireI2C Wire;

/*--- Arduino Functions ---*/
float atan2(uint16 y, uint16 x);

/*-----------------GPIO------------------*/
void pinMode(uint8 pin, uint8 TYPE);
void digitalWrite(uint8 pin, bool flag);
uint32 pulseIn(uint8 pin, bool flag);
bool digitalRead(uint8 pin);
void analogWrite(uint8 pin, uint8 PWM);
uint8 analogRead(uint8 pin);

/*--------------Interrupt-----------------*/
void attachInterrupt(uint8 numberOfInterrupt,void (*func)(), uint8 type);

/*-----------Time Functions--------------*/
void delay(int time);
void delayMicroseconds(int time);
uint64 millis(void);
#endif
#endif

