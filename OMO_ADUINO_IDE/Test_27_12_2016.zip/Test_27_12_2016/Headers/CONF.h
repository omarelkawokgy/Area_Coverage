
#ifndef CONF_H
#define CONF_H
#undef ENABLE_SIMULATION
#ifndef ENABLE_SIMULATION
#include <Arduino.h>
#endif
#define MAP_ROW 20
#define MAP_COLUMN 20

/*This area includes all standard PIN numbers needed for the project
most probably it will be included in all modules
---------------------------------------------------- - */

/*status of the slots on the map*/
#define BUSY_SLOT 0xFF
#define VACUMMED_SLOT 0xF0
#define UNDEFINED_SLOT 0x00

/*pins of the sensors*/
#define FRONT_SENSOR_INTERRUPT_NUMBER 0
#define RIGHT_SENSOR_PIN 8
#define LEFT_SENSOR_PIN 7
#define ENCODER_INTERRUPT_NUMBER 1

/*pins of the motors*/
#define RIGHT_MOTOR_POSITIVE_PIN 10
#define RIGHT_MOTOR_GROUND_PIN 9

#define LEFT_MOTOR_POSITIVE_PIN 6
#define LEFT_MOTOR_GROUND_PIN 5

#define LEFT_MOTOR_ENABLE_PIN 12
#define RIGHT_MOTOR_ENABLE_PIN 13

/*pins of LED*/
#define RED_LED_CONNECTION_CHECK_PIN 11
#define GREEN_LED_RUNNING_PIN 4
#define BLUE_LED_BLUETOOTH_PIN 3

/*Pins of Bluetooth*/
#define BLUETOOTH_RECIEVER_PIN 0
#define BLUETOOTH_TRANSMITTER_PIN 1

#define HIGH_PWM 127
#define LOW_PWM 0

/*standard distances for empty and busy*/
#define SIZE_OF_SLOT 20

#define MIDDLE 100
#define CHECK_IF_LOW(X) (X < MIDDLE)?TRUE:FALSE
#define CHECK_IF_HIGH(X) (X > MIDDLE)?TRUE:FALSE
#define ANALOG_PIN_ZERO 0
#define FORWARD_SINGLE_STEP_TIMEOUT_VALUE 40000
#define MAX_NUMBER_OF_DIRECTION_FIXES 10

/*-------------Map Conf------------*/
#define POINT_LIST_SIZE 20

#define INVALID_RESULT 0
#define X_ROBOT_GR_X_GOAL_Y_ROBOT_GR_Y_GOAL 1
#define X_ROBOT_LES_X_GOAL_Y_ROBOT_LES_Y_GOAL 2
#define X_ROBOT_LES_X_GOAL_Y_ROBOT_GR_Y_GOAL 3
#define X_ROBOT_GR_X_GOAL_Y_ROBOT_LES_Y_GOAL 4
#define X_ROBOT_EQ_X_GOAL_Y_ROBOT_GR_Y_GOAL 5
#define X_ROBOT_EQ_X_GOAL_Y_ROBOT_LES_Y_GOAL 6
#define X_ROBOT_GR_X_GOAL_Y_ROBOT_EQ_Y_GOAL 7
#define X_ROBOT_LES_X_GOAL_Y_ROBOT_EQ_Y_GOAL 8
#define X_ROBOT_EQ_X_GOAL_Y_ROBOT_EQ_Y_GOAL 9



#define INVALID_ANGLE_VALUE 0
#define ALLOWED_ANGLE_ERROR 7


/*-----------Robot conf--------------*/
#define ROBOT_INIT_X		(MAP_ROW/2)
#define ROBOT_INIT_Y		(MAP_COLUMN/2)
#define ROBOT_INIT_THETA	0
#define ROBOT_WHEEL_SIZE 20//in cm
#define ROBOT_SIZE 25 //in cm
#ifdef ENABLE_SIMULATION
#	define ROBOT_SINGLE_STEP 10
#else
#	define ROBOT_SINGLE_STEP 300
#endif

/*----------Scan conf-------------*/
#define SCAN_ANGLE 30
/*for circular scans only temp. closed*/
#define FULL_SCAN_NUM (FULL_CIRCLE_VALUE/(SCAN_ANGLE*2))
/*scan 3 times in each block*/
#define STEP_LINEAR_SCAN 1//((int)(ROBOT_SIZE/3))
#define SCAN_0_ANGLE 0
#define SCAN_30_ANGLE 1
#define SCAN_60_ANGLE 2
#define SCAN_90_ANGLE 3
#define SCAN_120_ANGLE 4
#define SCAN_150_ANGLE 5

/*Possible values*/
#define FAILURE_READING 0

#define LEFT_BUSY_RIGHT_EMPTY 1
#define LEFT_EMPTY_RIGHT_BUSY 2
#define LEFT_BUSY_RIGHT_BUSY 3

#define LEFT_CLEANED_RIGHT_EMPTY 4
#define LEFT_EMPTY_RIGHT_CLEANED 5
#define LEFT_CLEANED_RIGHT_CLEANED 6

#define LEFT_CLEANED_RIGHT_BUSY 7
#define LEFT_BUSY_RIGHT_CLEANED 8

#define LEFT_EMPTY_RIGHT_EMPTY 9


/*--------------------MACRO CONTROLS--------------------*/
#define DEBUG
#undef RECTANGLE
#undef USING_MAP_LIBRARY
#undef WORKING_WITH_ANGLES
#undef FINISHUP_EMPTY_SLOTS
#define SINGLE_ENCODER_ROBOT
#undef GO_TO_GOAL_STRAIGHTLINES
#undef ARDUINO_HARDWARE_CONNECTED
#undef UPDATE_POINT_POSITION
#undef ENCODER_ON_INTERRUPT
#undef USE_BLUETOOTH
#define FILTERED_COMPASS_READING

/*----------------return types-------------------------*/
#define RET_NOT_OK 0
#define RET_OK 1

/*----------------Hardware configuration--------------*/
#define I2C_ADDRESS 0x1E
#define HIT_OBSTICAL_DELAY_TIME (500) /*in micro seconds*/
#define INIT_COMPASS_ANGLE_DELAY_TIME 50
#define COMPASS_CONNECTION_CHECK_DELAY_TIME 100
#define SHOW_4_DIRECTION_VALUES_TIME 2000
#define MOTOR_CONNECTION_CHECK_DELAY_TIME 500
#define BLUETOOTH_SETUP_CONNECTION_DELAY_TIME 2000

/*------------------COMPASS DATA----------------*/
#define NORTH_LEFT_RANGE (NORTH_VALUE + ALLOWED_ANGLE_ERROR + 3)
#define NORTH_RIGHT_RANGE (NORTH_VALUE - ALLOWED_ANGLE_ERROR - 3)
#define EAST_LEFT_RANGE (EAST_VALUE + ALLOWED_ANGLE_ERROR)
#define EAST_RIGHT_RANGE (EAST_VALUE - ALLOWED_ANGLE_ERROR)
#define SOUTH_LEFT_RANGE (SOUTH_VALUE + ALLOWED_ANGLE_ERROR)//10
#define SOUTH_RIGHT_RANGE (SOUTH_VALUE - ALLOWED_ANGLE_ERROR)//351
#define WEST_LEFT_RANGE (WEST_VALUE + ALLOWED_ANGLE_ERROR)
#define WEST_RIGHT_RANGE (WEST_VALUE - ALLOWED_ANGLE_ERROR)

#endif

/*INTERRUPT VARIABLES*/
/*Timer interrupts*/
#define MS_SCALE 1000
#define TIME_OF_TURN_SECONDS 10 * MS_SCALE

#ifdef ENABLE_SIMULATION
#define PI 3.14159265359
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT 0
#define FALLING 0
#define HEX 0
#define DEC 1
#ifdef ENABLE_SIMULATION
typedef signed short int16_t;
#endif
#endif

//#define CONVERT_FROM_RAD_TO_DEG (180/PI)
#define CONVERT_FROM_DEG_TO_RAD (PI/180)

/*-------------------MOVEH CFG--------------------*/
#define MIN_PWM_VALUE_PERCENT 40
#define MAX_TURN_ANGLE 200
#define FULL_PERCENT 100
#define HIGH_PWM_VALUE_PERCENT 70 

#define FULL_CIRCLE_VALUE 360
#define HALF_CIRCLE_VALUE 180
#define MAX_PWM 255