#ifndef SERIALOBJ_H
#define SERIALOBJ_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION
class SerialCom
{
public:
	SerialCom();
	~SerialCom();

	void begin(int speed);
	void print(int number);
	void println(int number);
	void print(char* string);
	void println(char* string);
	void print(char character);
	void println(char character);
	void print(int number, int type);
	void println(int number, int type);
	void println(void);
	void println(double num);
	void print(double num);
};

#endif
#endif