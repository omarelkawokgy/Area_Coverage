#ifndef PHYS_ENCODER_H
#define PHYS_ENCODER_H

bool isEncoderOn();

void updatingEncoder(void);

#endif