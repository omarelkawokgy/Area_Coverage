#ifndef PHYS_COMPASS_H
#define PHYS_COMPASS_H

bool isCompass_CCW();

bool isCompass_CW();

float updateCompassValue();

double calcAngleIncrementPercent(void);

#endif