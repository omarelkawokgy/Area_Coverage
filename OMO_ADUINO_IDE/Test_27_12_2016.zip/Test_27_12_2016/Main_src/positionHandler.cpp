#include "Project_Path.h"
#include RELATIVE_PATH(positionHandler.h)
#include RELATIVE_PATH(COMH.h)
#include RELATIVE_PATH(MOVH.h)
#undef PROJECT_PATH_H

positionHeadingHandler::positionHeadingHandler(int8 _X_Robot, int8  _Y_Robot, int16 _theta_Robot)
{
	X_Robot = _X_Robot;
	Y_Robot = _Y_Robot;
	theta_Robot = _theta_Robot;
}

//initial position where the robot starts its corrdinate and bearing
positionHeadingHandler& positionHeadingHandler::getInstance(void)
{
	static positionHeadingHandler cleaner;
	return cleaner;
}

right_encoder& positionHeadingHandler::getRightEncoder()
{
	return encoder;
}

Comp& positionHeadingHandler::getCompass()
{
	return compass;
}

//getting position of the robot
RobotPos positionHeadingHandler::GetRobotPosition(void)
{
	RobotPos position;
	position.X_pos = X_Robot;
	position.Y_pos = Y_Robot;
	position.theta = theta_Robot;
	return position;
}

Heading positionHeadingHandler::GetRobotHeading(void)
{
	Heading tempHeading = INVALID_DIRECTION;

	(void)positionHeadingHandler::getTheta();
	tempHeading = Comp::calcRobotHeading(theta_Robot);

	return tempHeading;
}

//updating the position of the robot
void positionHeadingHandler::SetPosition(RobotPos _position)
{
	X_Robot = _position.X_pos;
	Y_Robot = _position.Y_pos;
	theta_Robot = _position.theta;
}

void positionHeadingHandler::setTheta(int16 angle)
{
	theta_Robot = angle;
}

int16 positionHeadingHandler::getTheta(void)
{
	theta_Robot = ReadRawData();
	return theta_Robot;
}

