#include "Project_Path.h"
#include RELATIVE_PATH(COMH.h)
#include RELATIVE_PATH(ERRH.h)
#include SIMULATION_PATH(SIMU.h)
#undef PROJECT_PATH_H

#define CONVERT_FROM_RAD_TO_DEG (HALF_CIRCLE_VALUE/PI)

 /*values of directions*/
#if 0
int16 NORTH_VALUE = 0;
int16 EAST_VALUE = 90;
int16 SOUTH_VALUE = 180;
int16 WEST_VALUE = 270;
#else
int16 NORTH_VALUE = 190;
int16 EAST_VALUE = 89;
int16 SOUTH_VALUE = 6;
int16 WEST_VALUE = 302;
#endif

static int16 offset = 0;

Comp::Comp()
{
	//Put the HMC5883 IC into the correct operating mode
	Wire.beginTransmission(I2C_ADDRESS); //open communication with HMC5883
	Wire.write(0x02); //select mode register
	Wire.write(0x00); //continuous measurement mode
	Wire.endTransmission();
}

Comp& Comp::getInstance(void)
{
	static Comp compass;
	return compass;
}

void Comp::InitializeDirections(void)
{
  offset = Comp::ReadRawData();
  Serial.println(offset);
}

int16 Comp::ReadRawData(void)
{
	//triple axis data
	int16_t x = 0;
	int16_t y = 0;
	int16_t z = 0;

	double heading = 0;
	//Tell the HMC5883L where to begin reading data
	Wire.beginTransmission(I2C_ADDRESS);
	Wire.write(0x03); //select register 3, X MSB register
	Wire.endTransmission();
	
	//Read data from each axis, 2 registers per axis
	Wire.requestFrom(I2C_ADDRESS, 6);

	if(6<=Wire.available())
	{
		x = Wire.read()<<8; //X msb
		x |= Wire.read(); //X lsb
		z = Wire.read()<<8; //Z msb
		z |= Wire.read(); //Z lsb
		y = Wire.read()<<8; //Y msb
		y |= Wire.read(); //Y lsb
	}

	heading = atan2(y,z);

	heading *= CONVERT_FROM_RAD_TO_DEG;

	//offset to force North to be equal 0

	if(heading < 0)
	{
		heading += FULL_CIRCLE_VALUE;
	}
	else if (heading > FULL_CIRCLE_VALUE)
	{
		heading -= FULL_CIRCLE_VALUE;
	}

#ifdef FILTERED_COMPASS_READING
	{
		heading = Comp::compassKalmanFilter1D(&heading);
	}
#endif
	return (int)(heading + 0.5);
}

#ifdef FILTERED_COMPASS_READING
#define PROCESS_NOISE 2.5
#define MEASUREMENTS_NOISE 1.2

double Comp::compassKalmanFilter1D(double* Z)
{
	static double X = 0;
	static double P = 1000;
	static double K = 0;

	if ((X > (FULL_CIRCLE_VALUE - ALLOWED_ANGLE_ERROR)) && (*Z < ALLOWED_ANGLE_ERROR))
	{
		X = 0;
		K = 0;
		P = 1000;
	}

	P = P * PROCESS_NOISE;

	K = (P / (P + MEASUREMENTS_NOISE));
	X = X + K * (*Z - X);
	P = (1 - K) * P;

	if (X < 0)
	{
		X += FULL_CIRCLE_VALUE;
	}
	else if (X > FULL_CIRCLE_VALUE)
	{
		X -= FULL_CIRCLE_VALUE;
	}

	return (X);
}
#endif

Heading Comp::ReadComp(void)
{

  Heading Angle;
  int16 tempAngle;

  tempAngle = ReadRawData();

  Angle = Comp::calcRobotHeading(tempAngle);

  return Angle;
}

Heading Comp::calcRobotHeading(int16 tempAngle)
{
	Heading Angle = INVALID_DIRECTION;
	int16 currentSouthAngle = 0;
	int16 currentNorthAngle = 0;
	int16 currentWestAngle = 0;
	int16 currentEastAngle = 0;


	if (((int)(SOUTH_RIGHT_RANGE) < 0) && (tempAngle > HALF_CIRCLE_VALUE))
	{
			currentSouthAngle = tempAngle - 360;
	}
	else
	{
		currentSouthAngle = tempAngle;
	}

	if (((int)(NORTH_RIGHT_RANGE) < 0) && (tempAngle > HALF_CIRCLE_VALUE))
	{
			currentNorthAngle = tempAngle - 360;
	}
	else
	{
		currentNorthAngle = tempAngle;
	}

	if (((int)(WEST_RIGHT_RANGE) < 0) && (tempAngle > HALF_CIRCLE_VALUE))
	{
			currentWestAngle = tempAngle - 360;
	}
	else
	{
		currentWestAngle = tempAngle;
	}

	if (((int)(EAST_RIGHT_RANGE) < 0) && (tempAngle > HALF_CIRCLE_VALUE))
	{
			currentEastAngle = tempAngle - 360;
	}
	else
	{
		currentEastAngle = tempAngle;
	}
	

	if ((currentNorthAngle >= (NORTH_RIGHT_RANGE)) && (currentNorthAngle <= (NORTH_LEFT_RANGE)))
	{
		Angle = NORTH;
	}
	else if ((currentWestAngle >= (WEST_RIGHT_RANGE) && (currentWestAngle <= (WEST_LEFT_RANGE))))
	{
		Angle = WEST;
	}
	else if ((currentSouthAngle >= (SOUTH_RIGHT_RANGE)) && (currentSouthAngle <= (SOUTH_LEFT_RANGE)))
	{
		Angle = SOUTH;
	}
	else if ((currentEastAngle >= (EAST_RIGHT_RANGE)) && (currentEastAngle <= (EAST_LEFT_RANGE)))
	{
		Angle = EAST;
	}
	else
	{
		/*TODO handling wrong calling while not being in 4 directions*/
		Angle = INVALID_DIRECTION;
		ERRH::Error_logErrorClass(ERROR_COMH_INVALID_HEADING);
	}
	return Angle;
}

return_type Comp::CheckConnection(void)
{
	return_type ret = RET_NOT_OK;
	int16 TempAngle = UINT_SNA;
	int16 CurrentAngle = UINT_SNA;

	TempAngle = Comp::ReadRawData();
	delay(COMPASS_CONNECTION_CHECK_DELAY_TIME);
	CurrentAngle = Comp::ReadRawData();

	if (TempAngle != CurrentAngle)
	{
		ret = RET_OK;
	}
	else
	{
		ERRH::Error_logErrorClass(ERROR_COMH_COMPASS_NC);
	}
	return ret;
}
