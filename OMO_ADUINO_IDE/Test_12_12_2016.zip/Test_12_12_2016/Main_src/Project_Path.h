#define PROJECT_ROOT C:/Users/oelkawok/Desktop/Test_12_12_2016 
#ifndef PROJECT_PATH_H
#define PROJECT_PATH_H

#define TO_STRING(s) #s
#define ABSOLUTE_PATH(root, relative_path) TO_STRING(root/relative_path)
#define RELATIVE_PATH(library) ABSOLUTE_PATH(PROJECT_ROOT/Headers, library)
#define SIMULATION_PATH(library) ABSOLUTE_PATH(PROJECT_ROOT/Main_src/Simulation_Code, library)
#endif
