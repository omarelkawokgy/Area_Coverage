#include "PhysEncoder.h"
#include "PinMODE.h"
#include "PhysMotor.h"
#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

bool isEncoderOn()
{
	bool ret = FALSE;
	if (isRightMotorEnabled())
	{
		if (isRightMotorForward() || isRightMotorBackward())
		{
			ret = TRUE;
		}
	}
	return ret;
}