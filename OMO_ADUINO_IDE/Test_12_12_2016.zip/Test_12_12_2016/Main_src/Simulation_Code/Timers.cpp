#include "Timers.h"
#include "PhysULS.h"
#include <iostream>
using namespace std;

#include "UNO_GPIO.h"

/*-----------Time Functions--------------*/
void delay(int time)
{

}

void delayMicroseconds(int time)
{

}

uint64 millis(void)
{
	return 0;
}

uint64 pulseIn(uint8 pin, bool flag)
{
	uint64 timeDuration = 0;
	if (pin == LEFT_SENSOR_PIN)
	{
		if (pulseOccuredLeft(TRUE))
		{
			timeDuration = CM_TO_MICRO_SECONDS(200);
		}
	}
	else if (pin == RIGHT_SENSOR_PIN)
	{
		if (pulseOccuredRight(TRUE))
		{
			timeDuration = CM_TO_MICRO_SECONDS(200);
		}
	}

	return timeDuration;
}