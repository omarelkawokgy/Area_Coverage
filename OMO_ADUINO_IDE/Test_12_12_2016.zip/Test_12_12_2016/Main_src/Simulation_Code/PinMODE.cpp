#include "PinMODE.h"
#include <iostream>
using namespace std;

PinModeObj digitalPinArray[DIGITAL_GPIO_SIZE];
PinModeObj analogPinArray[ANALOG_GPIO_SIZE];

PinModeObj::PinModeObj()
{
	/*default constructor*/
}

PinModeObj::~PinModeObj()
{

}

PinModeObj::PinModeObj(uint8 _pin, uint8 _type, uint8 _value)
{
	pin = _pin;
	type = _type;
	value = _value;
}

uint8 PinModeObj::getPin()
{
	return pin;
}
uint8 PinModeObj::getType()
{
	return type;
}

void PinModeObj::setPin(uint8 _pin)
{
	pin = _pin;
}
void PinModeObj::setType(uint8 _type)
{
	type = _type;
}

void pinMode(uint8 _pin, uint8 TYPE)
{
	digitalPinArray[_pin].setType(TYPE);
	analogPinArray[_pin].setType(TYPE);
}

uint8 PinModeObj::getValue()
{
	return value;
}

void PinModeObj::setValue(uint8 _value)
{
	value = _value;
}