#ifndef UNO_GPIO_H
#define UNO_GPIO_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)



class GPIO
{
public:
	GPIO();
	bool DigitalULSRightFlag;
	bool DigitalULSLeftFlag;
private:

};
extern GPIO gpio;

/*-----------------GPIO------------------*/
void digitalWrite(uint8 pin, bool flag);
bool digitalRead(uint8 pin);
void analogWrite(uint8 pin, uint8 PWM);
uint8 analogRead(uint8 pin);


#endif