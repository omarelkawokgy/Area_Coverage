#ifndef ULS_H
#define ULS_H

bool pulseOccuredLeft(bool pulseReadFlag);

bool pulseOccuredRight(bool pulseReadFlag);

#endif