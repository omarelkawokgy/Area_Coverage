#include "PhysULS.h"
#include "PinMODE.h"
#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)


bool pulseOccuredLeft(bool pulseReadFlag)
{
	static bool ret = FALSE;
	static bool lastPinValue = LOW;
	static bool cleanReturn = FALSE;

	if (lastPinValue != digitalPinArray[LEFT_SENSOR_PIN].getValue())
	{
		if ((lastPinValue == HIGH) && (digitalPinArray[LEFT_SENSOR_PIN].getValue() == LOW))
		{
			ret = TRUE;
		}

		lastPinValue = digitalPinArray[LEFT_SENSOR_PIN].getValue();
	}

	if (cleanReturn)
	{
		ret = FALSE;
	}
	cleanReturn = pulseReadFlag;
	return ret;
}

bool pulseOccuredRight(bool pulseReadFlag)
{
	static bool ret = FALSE;
	static bool lastPinValue = LOW;
	static bool cleanReturn = FALSE;

	if (lastPinValue != digitalPinArray[RIGHT_SENSOR_PIN].getValue())
	{
		if ((lastPinValue == HIGH) && (digitalPinArray[RIGHT_SENSOR_PIN].getValue() == LOW))
		{
			ret = TRUE;
		}

		lastPinValue = digitalPinArray[RIGHT_SENSOR_PIN].getValue();
	}

	if (cleanReturn)
	{
		ret = FALSE;
	}
	cleanReturn = pulseReadFlag;

	return ret;
}