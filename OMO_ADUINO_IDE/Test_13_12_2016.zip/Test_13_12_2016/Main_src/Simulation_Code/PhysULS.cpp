#include "PhysULS.h"
#include "PinMODE.h"

static uint16 leftDistValue = 200;
static uint16 rightDistValue = 200;

bool pulseOccuredLeft(bool pulseReadFlag)
{
	static bool ret = FALSE;
	static bool lastPinValue = LOW;
	static bool cleanReturn = FALSE;

	if (lastPinValue != digitalPinArray[LEFT_SENSOR_PIN].getValue())
	{
		if ((lastPinValue == HIGH) && (digitalPinArray[LEFT_SENSOR_PIN].getValue() == LOW))
		{
			ret = TRUE;
		}

		lastPinValue = digitalPinArray[LEFT_SENSOR_PIN].getValue();
	}

	if (cleanReturn)
	{
		ret = FALSE;
	}
	cleanReturn = pulseReadFlag;
	return ret;
}

bool pulseOccuredRight(bool pulseReadFlag)
{
	static bool ret = FALSE;
	static bool lastPinValue = LOW;
	static bool cleanReturn = FALSE;

	if (lastPinValue != digitalPinArray[RIGHT_SENSOR_PIN].getValue())
	{
		if ((lastPinValue == HIGH) && (digitalPinArray[RIGHT_SENSOR_PIN].getValue() == LOW))
		{
			ret = TRUE;
		}

		lastPinValue = digitalPinArray[RIGHT_SENSOR_PIN].getValue();
	}

	if (cleanReturn)
	{
		ret = FALSE;
	}
	cleanReturn = pulseReadFlag;

	return ret;
}

uint64 pulseIn(uint8 pin, bool flag)
{
	uint64 timeDuration = 0;
	if (pin == LEFT_SENSOR_PIN)
	{
		if (pulseOccuredLeft(TRUE))
		{
			timeDuration = CM_TO_MICRO_SECONDS(leftDistValue);
		}
	}
	else if (pin == RIGHT_SENSOR_PIN)
	{
		if (pulseOccuredRight(TRUE))
		{
			timeDuration = CM_TO_MICRO_SECONDS(rightDistValue);
		}
	}

	return timeDuration;
}