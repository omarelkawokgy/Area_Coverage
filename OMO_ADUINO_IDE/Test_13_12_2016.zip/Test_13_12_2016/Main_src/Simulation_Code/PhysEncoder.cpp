#include "PhysEncoder.h"
#include "PinMODE.h"
#include "PhysMotor.h"
#undef INPUT
#include "windows.h"
#define INPUT 0
#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

bool isEncoderOn()
{
	bool ret = FALSE;
	if (isRightMotorEnabled())
	{
		if (isRightMotorForward() || isRightMotorBackward())
		{
			ret = TRUE;
		}
	}
	return ret;
}

void updatingEncoder(void)
{
	if (isEncoderOn())
	{
		if (CHECK_IF_LOW(analogPinArray[ANALOG_PIN_ZERO].getValue()))
		{
			Sleep(100);
			analogPinArray[ANALOG_PIN_ZERO].setValue(HIGH_PWM);
		}
		else if (CHECK_IF_HIGH(analogPinArray[ANALOG_PIN_ZERO].getValue()))
		{
			Sleep(100);
			analogPinArray[ANALOG_PIN_ZERO].setValue(LOW_PWM);
		}
	}
}