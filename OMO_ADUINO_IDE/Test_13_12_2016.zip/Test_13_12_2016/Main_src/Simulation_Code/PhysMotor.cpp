#include "../Project_Path.h"
#include "PhysMotor.h"
#include "PinMODE.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

bool isleftMotorEnabled()
{
	bool ret = FALSE;
	if (digitalPinArray[LEFT_MOTOR_ENABLE_PIN].getValue())
	{
		ret = TRUE;
	}
	return ret;
}

bool isRightMotorEnabled()
{
	bool ret = FALSE;
	if (digitalPinArray[RIGHT_MOTOR_ENABLE_PIN].getValue())
	{
		ret = TRUE;
	}
	return ret;
}

bool isBothMotorsEnabled()
{
	bool ret = FALSE;
	if (isRightMotorEnabled() && isleftMotorEnabled())
	{
		ret = TRUE;
	}
	return ret;
}

bool isLeftMotorForward()
{
	bool ret = FALSE;
	if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == HIGH_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == LOW_PWM))
	{
		ret = TRUE;
	}
	return ret;
}

bool isRightMotorForward()
{
	bool ret = FALSE;
	if ((analogPinArray[RIGHT_MOTOR_POSITIVE_PIN].getValue() == HIGH_PWM)
		&& (analogPinArray[RIGHT_MOTOR_GROUND_PIN].getValue() == LOW_PWM))
	{
		ret = TRUE;
	}
	return ret;
}

bool isLeftMotorBackward()
{
	bool ret = FALSE;
	if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == LOW_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == HIGH_PWM))
	{
		ret = TRUE;
	}
	return ret;
}

bool isRightMotorBackward()
{
	bool ret = FALSE;
	if ((analogPinArray[RIGHT_MOTOR_POSITIVE_PIN].getValue() == LOW_PWM)
		&& (analogPinArray[RIGHT_MOTOR_GROUND_PIN].getValue() == HIGH_PWM))
	{
		ret = TRUE;
	}
	return ret;
}

bool isLeftMotorStop()
{
	bool ret = FALSE;
	if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == HIGH_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == HIGH_PWM))
	{
		ret = TRUE;
	}
	else if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == LOW_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == LOW_PWM))
	{
		ret = TRUE;
	}

	return ret;
}

bool isRightMotorStop()
{
	bool ret = FALSE;
	if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == HIGH_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == HIGH_PWM))
	{
		ret = TRUE;
	}
	else if ((analogPinArray[LEFT_MOTOR_POSITIVE_PIN].getValue() == LOW_PWM)
		&& (analogPinArray[LEFT_MOTOR_GROUND_PIN].getValue() == LOW_PWM))
	{
		ret = TRUE;
	}

	return ret;
}

bool isRobotForward()
{
	bool ret = FALSE;
	if (isLeftMotorForward() && isRightMotorForward())
	{
		ret = TRUE;
	}
	return ret;
}

bool isRobotBackward()
{
	bool ret = FALSE;
	if (isLeftMotorBackward() && isRightMotorBackward())
	{
		ret = TRUE;
	}
	return ret;
}

bool isRobotTurn_CCW()
{
	bool ret = FALSE;
	if (isLeftMotorBackward() && isRightMotorForward())
	{
		ret = TRUE;
	}
	return ret;
}

bool isRobotTurn_CW()
{
	bool ret = FALSE;
	if (isLeftMotorForward() && isRightMotorBackward())
	{
		ret = TRUE;
	}
	return ret;
}

bool isRobotStop()
{
	bool ret = FALSE;
	if (isLeftMotorStop() && isRightMotorStop())
	{
		ret = TRUE;
	}
	return ret;
}