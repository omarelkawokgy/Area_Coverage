
#ifndef SIMU_H
#define SIMU_H

#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION
#include "SerialObj.h"
#include "WireObj.h"
#include "UNO_GPIO.h"
#include "Timers.h"
#include "PinMODE.h"
#include "PhysULS.h"

extern SerialCom Serial;
extern WireI2C Wire;

/*--- Arduino Functions ---*/
float atan2(uint16 y, uint16 x);

/*--------------Interrupt-----------------*/
void attachInterrupt(uint8 numberOfInterrupt,void (*func)(), uint8 type);

#endif
#endif

