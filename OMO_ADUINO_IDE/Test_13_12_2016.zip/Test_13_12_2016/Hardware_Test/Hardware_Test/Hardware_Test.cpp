// Hardware_Test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "..\..\Main_src\Project_Path.h"
#include "..\..\Main_src\Main.h"
#include RELATIVE_PATH(RobotDevice.h)
#include RELATIVE_PATH(MapHandler.h)


int _tmain(int argc, _TCHAR* argv[])
{
	RobotDevice theCleaner = RobotDevice::getInstance();
	Map RoomMap;

	Init(theCleaner, RoomMap);
	while (1)
	{
		Main_CodeCyclic(theCleaner, RoomMap);
	}
	return 0;
}

