#ifndef TIMERS_H
#define TIMERS_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)



/*-----------Time Functions--------------*/
void delay(int time);
void delayMicroseconds(int time);
uint64 millis(void);

#endif 