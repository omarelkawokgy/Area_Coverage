#include "PhysRoom.h"
#include "../../Hardware_Test/Hardware_Test/Hardware_Test.h"
#include "..\Project_Path.h"
#include RELATIVE_PATH(Main_Func_1.h)

#define START 5
#define EMPTY_MAP_SLOT 0
#define BUSY_MAP_SLOT 1
#define CM_TO_MICRO_SECONDS(X) (X * 29.4118 * 2)

static enu_Direction_req calcDirectionReq(uint16 angle);
static uint16 convertFromSlotsToDistance(uint16 numSlots);

int VirtualRoom[MAP_ROW][MAP_COLUMN] = { 
		{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 5, 0, 1, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
};

void VirtualRoomBumperHitUpdate(void)
{
	RobotPos tempPosition = theCleaner.getTheMove().getPosition().GetRobotPosition();
	enu_Direction_req dirRequest = calcDirectionReq(tempPosition.theta);
	int X = tempPosition.X_pos;
	int Y = tempPosition.Y_pos;

	switch (dirRequest)
	{
	case REQUEST_NORTH:
		if (Y > 0)
		{
			Y--;
			Y--;
		}
		break;
	case REQUEST_EAST:
		if (X < MAP_ROW)
		X++;
		break;
	case REQUEST_SOUTH:
		if (Y < MAP_COLUMN)
		Y++;
		break;
	case REQUEST_WEST:
		if (X > 0)
		X--;
		X--;
		break;
	case REQUEST_NONE:
		break;
	default:
		break;
	}
	if (dirRequest != REQUEST_NONE)
	{
		if (VirtualRoom[Y][X] == BUSY)
		{
			BumperHit = TRUE;
		}
	}
}

static enu_Direction_req calcDirectionReq(uint16 angle)
{
	enu_Direction_req dirRequest = REQUEST_NONE;

	if ((angle <= (ALLOWED_ANGLE_ERROR)) || (angle >= (360 - ALLOWED_ANGLE_ERROR)))
	{
		dirRequest = REQUEST_NORTH;
	}
	else if ((angle >= (WEST_VALUE - ALLOWED_ANGLE_ERROR)) && (angle <= (WEST_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		dirRequest = REQUEST_WEST;
	}
	else if ((angle >= (SOUTH_VALUE - ALLOWED_ANGLE_ERROR)) && (angle <= (SOUTH_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		dirRequest = REQUEST_SOUTH;
	}
	else if ((angle >= (EAST_VALUE - ALLOWED_ANGLE_ERROR)) && (angle <= (EAST_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		dirRequest = REQUEST_EAST;
	}
	else
	{
		dirRequest = REQUEST_NONE;
	}
	return dirRequest;
}

uint16 CalcDistFromVirtualRoom(SensorID side)
{
	int DistanceCalc = 0;
	RobotPos tempPosition = theCleaner.getTheMove().getPosition().GetRobotPosition();
	int X = tempPosition.X_pos;
	int Y = tempPosition.Y_pos;
	enu_Direction_req dirRequest = calcDirectionReq(tempPosition.theta);
	int EmptySlotsSeen = 0;

		if (((side == LEFT_SENSOR) && (dirRequest == REQUEST_NORTH))
			|| ((side == RIGHT_SENSOR) && (dirRequest == REQUEST_SOUTH)))
		{
			for (int i = X; i >= 0; i--)
			{
				if (VirtualRoom[Y][i] == EMPTY_MAP_SLOT)
				{
					EmptySlotsSeen++;
				}
				else if (VirtualRoom[Y][i] == BUSY_MAP_SLOT)
				{
					break;
				}
			}
		}
		else if (((side == LEFT_SENSOR) && (dirRequest == REQUEST_SOUTH))
			|| ((side == RIGHT_SENSOR) && (dirRequest == REQUEST_NORTH)))
		{
			for (int i = X; i < MAP_ROW; i++)
			{
				if (VirtualRoom[Y][i] == EMPTY_MAP_SLOT)
				{
					EmptySlotsSeen++;
				}
				else if (VirtualRoom[Y][i] == BUSY_MAP_SLOT)
				{
					break;
				}
			}
		}
		DistanceCalc = convertFromSlotsToDistance(EmptySlotsSeen);

		return (CM_TO_MICRO_SECONDS(DistanceCalc));
}

static uint16 convertFromSlotsToDistance(uint16 numSlots)
{
	return (numSlots * ROBOT_SIZE);
}
