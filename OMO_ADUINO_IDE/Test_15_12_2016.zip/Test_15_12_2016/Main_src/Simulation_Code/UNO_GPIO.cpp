#include "UNO_GPIO.h"
#include "PhysMotor.h"
#include "PhysCompass.h"
#include "PhysEncoder.h"
#include "PhysULS.h"
#include "PhysRoom.h"
#include <iostream>
using namespace std;

/*-----------external includes-----------*/
#include "PinMODE.h"

/*---------Global Variables--------------*/
GPIO gpio;

GPIO::GPIO()
{

}

/*-----------------GPIO------------------*/
void digitalWrite(uint8 pin, bool flag)
{
	if (digitalPinArray[pin].getType() == INPUT)
	{
		cout << "writing on input pin: "<< (int)pin << endl;
	}
	else
	{
		digitalPinArray[pin].setValue(flag);

		if (pin == LEFT_SENSOR_PIN)
		{
			pulseOccuredLeft(FALSE);
		}
		else if (pin == RIGHT_SENSOR_PIN)
		{
			pulseOccuredRight(FALSE);
		}
	}
}

bool digitalRead(uint8 pin)
{
	bool digitalReading = true;
	switch (pin)
	{
	case RIGHT_SENSOR_PIN:
		break;
	case LEFT_SENSOR_PIN:
		break;
	case RIGHT_MOTOR_POSITIVE_PIN:
		break;
	case RIGHT_MOTOR_GROUND_PIN:
		break;
	case LEFT_MOTOR_POSITIVE_PIN:
		break;
	case LEFT_MOTOR_GROUND_PIN:
		break;
	case LEFT_MOTOR_ENABLE_PIN:
		break;
	case RIGHT_MOTOR_ENABLE_PIN:
		break;
	case RED_LED_CONNECTION_CHECK_PIN:
		break;
	case GREEN_LED_RUNNING_PIN:
		break;
	case BLUE_LED_BLUETOOTH_PIN:
		break;
	case BLUETOOTH_RECIEVER_PIN:
		break;
	case BLUETOOTH_TRANSMITTER_PIN:
		break;
	default:
		break;
	}
	return digitalReading;
}

void analogWrite(uint8 pin, uint8 PWM)
{
	if (analogPinArray[pin].getType() == INPUT)
	{
		cout << "writing on input pin: " << (int)pin << endl;
	}
	else
	{
		analogPinArray[pin].setValue(PWM);
	}
}

uint8 analogRead(uint8 pin)
{
	switch (pin)
	{
	case ANALOG_PIN_ZERO:
		updatingEncoder();
		VirtualRoomBumperHitUpdate();
		break;
	case LEFT_SENSOR_PIN:
		break;
	case RED_LED_CONNECTION_CHECK_PIN:
		break;
	case GREEN_LED_RUNNING_PIN:
		break;
	case BLUE_LED_BLUETOOTH_PIN:
		break;
	case BLUETOOTH_TRANSMITTER_PIN:
		break;
	default:
		break;
	}
	return analogPinArray[pin].getValue();
}

