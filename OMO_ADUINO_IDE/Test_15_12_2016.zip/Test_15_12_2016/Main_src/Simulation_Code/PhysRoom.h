#ifndef PHYS_ROOM_H
#define PHYS_ROOM_H
#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)

void VirtualRoomBumperHitUpdate(void);
uint16 CalcDistFromVirtualRoom(SensorID side);
#endif