#ifndef PHYMOTOR_H
#define PHYMOTOR_H

bool isleftMotorEnabled();
bool isRightMotorEnabled();
bool isBothMotorsEnabled();

bool isLeftMotorForward();
bool isRightMotorForward();

bool isLeftMotorBackward();
bool isRightMotorBackward();

bool isLeftMotorStop();
bool isRightMotorStop();

bool isRobotForward();
bool isRobotBackward();
bool isRobotTurn_CCW();
bool isRobotTurn_CW();
bool isRobotStop();


#endif