#include "Timers.h"
#ifdef ENABLE_SIMULATION
#include "PhysULS.h"
#include <iostream>
using namespace std;

#include "UNO_GPIO.h"

/*-----------Time Functions--------------*/
void delay(int time)
{

}

void delayMicroseconds(int time)
{

}

uint64 millis(void)
{
	return 0;
}
#endif
