#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION
#include "physCompass.h"
#include "PhysMotor.h"
#undef INPUT
#include "windows.h"


bool isCompass_CCW()
{
	bool ret = FALSE;
	if (isRobotTurn_CCW())
	{
		ret = TRUE;
	}
	return ret;
}

bool isCompass_CW()
{
	bool ret = FALSE;
	if (isRobotTurn_CW())
	{
		ret = TRUE;
	}
	return ret;
}

float updateCompassValue()
{
	static float angle = 30;
	if (isRobotTurn_CW())
	{
		if (angle < 358)
		{
			angle += 2;
		}
		else
		{
			angle = 0;
		}
	}
	else if (isRobotTurn_CCW())
	{
		if (angle > 2)
		{
			angle -= 2;
		}
		else
		{
			angle = 360;
		}
	}
	Sleep(10);
	return angle;

}

#endif