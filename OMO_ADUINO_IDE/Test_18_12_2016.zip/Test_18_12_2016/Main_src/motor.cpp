/*
 * motor.cpp
 *
 *  Created on: Oct 24, 2016
 *      Author: Omar Elkawokgy
 */
#include "Project_Path.h"
#include RELATIVE_PATH(motor.h)
#include SIMULATION_PATH(SIMU.h)

#define DECIMAL_PERCENTAGE(X) (((float)X)/100) 

motor::motor()
{

}

void motor::assignMotorID(motorIds_T _motorId)
{
	if(_motorId == LEFT_MOTOR)
	{
		motorPins.motorPositivePin = 10;
		motorPins.motorGroundPin = 9;
	}
	else
	{
		motorPins.motorPositivePin = 6;
		motorPins.motorGroundPin = 5;
	}
}


void motor::stop()
{
	analogWrite(motorPins.motorPositivePin, LOW_PWM);
	analogWrite(motorPins.motorGroundPin, LOW_PWM);
}

void motor::forward()
{
	analogWrite(motorPins.motorPositivePin, HIGH_PWM);
	analogWrite(motorPins.motorGroundPin, LOW_PWM);
}

void motor::backward()
{
	analogWrite(motorPins.motorPositivePin, LOW_PWM);
	analogWrite(motorPins.motorGroundPin, HIGH_PWM);
}

void motor::forward(uint8 percentage)
{
	Serial.print("percentage: ");
	Serial.println((int)DECIMAL_PERCENTAGE(percentage) * MAX_PWM);
	analogWrite(motorPins.motorPositivePin, ((DECIMAL_PERCENTAGE(percentage)) * MAX_PWM));
	analogWrite(motorPins.motorGroundPin, LOW_PWM);
}

void motor::backward(uint8 percentage)
{
	analogWrite(motorPins.motorPositivePin, LOW_PWM);
	analogWrite(motorPins.motorGroundPin, ((DECIMAL_PERCENTAGE(percentage)) * MAX_PWM));
}
