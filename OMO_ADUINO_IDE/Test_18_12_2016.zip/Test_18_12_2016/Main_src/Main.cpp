#include "Project_Path.h"
#include RELATIVE_PATH(positionHandler.h)
#include RELATIVE_PATH(ERRH.h)
#include RELATIVE_PATH(Main_Func_1.h)
#include RELATIVE_PATH(ZGZG.h)
#include RELATIVE_PATH(GTSP.h)
#include RELATIVE_PATH(COMH.h)
#include RELATIVE_PATH(MOVH.h)
#include RELATIVE_PATH(RobotDevice.h)
#include RELATIVE_PATH(Bluetooth.h)
#include SIMULATION_PATH(SIMU.h)
#undef PROJECT_PATH_H

/*-----------------------------global variable declaration---------------------------------*/
/*_________FLAGS____________*/
volatile Boolean BumperHit = FALSE;

Boolean ZigZagFlag = FALSE;

Boolean ToStartPoint = TRUE;
/*_________OBJECTS__________*/
enu_Direction_req Direction_req = REQUEST_NORTH;

/*-----------------static functions declaration------------------*/
static void ISR_BumperHit(void);

#ifdef DEBUG
static void Map_Print(Map& room, RobotDevice& theCleaner);
static char calcPointToPrint(RobotDevice& theCleaner);
#endif

void Init(RobotDevice& theCleaner, Map& RoomMap)
{
	/*input and output pins*/
	pinMode(RIGHT_MOTOR_POSITIVE_PIN, OUTPUT);
	pinMode(RIGHT_MOTOR_GROUND_PIN, OUTPUT);
	pinMode(LEFT_MOTOR_POSITIVE_PIN, OUTPUT);
	pinMode(LEFT_MOTOR_GROUND_PIN, OUTPUT);
	pinMode(RED_LED_CONNECTION_CHECK_PIN, OUTPUT);
	pinMode(GREEN_LED_RUNNING_PIN, OUTPUT);
	pinMode(BLUE_LED_BLUETOOTH_PIN, OUTPUT);

	pinMode(ENCODER_INTERRUPT_NUMBER, INPUT);

	pinMode(RIGHT_MOTOR_ENABLE_PIN, OUTPUT);
	pinMode(LEFT_MOTOR_ENABLE_PIN, OUTPUT);

		digitalWrite(RIGHT_MOTOR_ENABLE_PIN, HIGH);
		digitalWrite(LEFT_MOTOR_ENABLE_PIN, HIGH);

        Serial.print("NORTH initial value: ");
        Serial.println(NORTH_VALUE);

		Serial.print("EAST initial value: ");
		Serial.println(EAST_VALUE);

		Serial.print("SOUTH initial value: ");
		Serial.println(SOUTH_VALUE);

        Serial.print("WEST initial value: ");
        Serial.println(WEST_VALUE);

        delay(SHOW_4_DIRECTION_VALUES_TIME);
  
	/*pin 0 in interrupt is pin 2 in arduino*/
		attachInterrupt(FRONT_SENSOR_INTERRUPT_NUMBER, ISR_BumperHit, FALLING);

	/*------------------Map Init Data-------------------*/
	
	RoomMap.initMap();

	/*----------------Robot Init Data------------------*/
	RobotPos RobTempPosition = theCleaner.getTheMove().getPosition().GetRobotPosition();

#ifdef CONNECTION_CHECK
	if(theCleaner.checkConnection())
	{
		digitalWrite(RED_LED_CONNECTION_CHECK_PIN, HIGH);
	}
#endif
	/*=========================Start Implementation=======================*/
	RoomMap.addRobotOnMap(RobTempPosition.Y_pos, RobTempPosition.X_pos);

	digitalWrite(GREEN_LED_RUNNING_PIN, HIGH);

	theCleaner.getTheMove().getPosition().getCompass();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().InitializeDirections();
#ifdef FILTERED_COMPASS_READING
	/*to Stablize the Kalman filter*/
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
	theCleaner.getTheMove().getPosition().getCompass().ReadRawData();
#endif

}

void Main_CodeCyclic(RobotDevice& theCleaner, Map& RoomMap)
{
	Serial.print("Direction_req: ");
Serial.println(Direction_req);

		/*go to extreme left of map to scan room*/
		GTSP::GoToStartPoint(theCleaner, RoomMap, &Direction_req);

		ZGZG::ZigZagRoutine(theCleaner, RoomMap, &Direction_req);

#ifdef DEBUG
		Map_Print(RoomMap, theCleaner);
#endif

}


void ISR_BumperHit(void)
{
  #ifdef DEBUG
  Serial.println("interrupt hit");
  #endif
  MOVE moveit = MOVE::getInstance();
  moveit.MoveStop();
  BumperHit = TRUE;
}



#ifdef DEBUG
static void Map_Print(Map& map, RobotDevice& theCleaner)
{
	for (int8 i = 0; i < MAP_ROW; i++)
	{
		for (int8 j = 0; j < MAP_COLUMN; j++)
		{
			if ((int)map.ReadPointFromMap(i, j) == ROBOT)
			{
				Serial.print((char)calcPointToPrint(theCleaner));
			}
			else
			{
				Serial.print((int)map.ReadPointFromMap(i, j));
			}
		}
		Serial.println();
	}
	Serial.println();
}

static char calcPointToPrint(RobotDevice& theCleaner)
{
	RobotPos tempRobotPos = theCleaner.getTheMove().getPosition().GetRobotPosition();
	int16 angle = tempRobotPos.theta;
	char ret = '5';

	if (((int)angle <= (ALLOWED_ANGLE_ERROR)) || ((int)angle >= (360 - ALLOWED_ANGLE_ERROR)))
	{
		ret = '^';
	}
	else if (((int)angle >= ((int)WEST_VALUE - ALLOWED_ANGLE_ERROR)) && ((int)angle <= ((int)WEST_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		ret = '<';
	}
	else if (((int)angle >= ((int)SOUTH_VALUE - ALLOWED_ANGLE_ERROR)) && ((int)angle <= ((int)SOUTH_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		ret = 'V';
	}
	else if (((int)angle >= ((int)EAST_VALUE - ALLOWED_ANGLE_ERROR)) && ((int)angle <= ((int)EAST_VALUE + ALLOWED_ANGLE_ERROR)))
	{
		ret = '>';
	}
	else
	{
		ret = '5';
	}
	return ret;
}
#endif
