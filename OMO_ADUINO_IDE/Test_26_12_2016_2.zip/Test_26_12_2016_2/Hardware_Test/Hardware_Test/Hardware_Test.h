#ifndef HARDWARE_TEST_H
#define HARDWARE_TEST_H
#include "..\..\Main_src\Main.h"
#include RELATIVE_PATH(CONF.h)
#include RELATIVE_PATH(types.h)

extern RobotDevice theCleaner;
extern Map RoomMap;
#endif