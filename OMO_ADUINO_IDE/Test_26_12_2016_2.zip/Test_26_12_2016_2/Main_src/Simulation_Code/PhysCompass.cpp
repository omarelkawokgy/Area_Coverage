#include "../Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION
#include "physCompass.h"
#include "PhysMotor.h"
#undef INPUT
#include "windows.h"


bool isCompass_CCW()
{
	bool ret = FALSE;
	if (isRobotTurn_CCW())
	{
		ret = TRUE;
	}
	return ret;
}

bool isCompass_CW()
{
	bool ret = FALSE;
	if (isRobotTurn_CW())
	{
		ret = TRUE;
	}
	return ret;
}

float updateCompassValue()
{
	static float angle = 30;
	double angleincrement = calcAngleIncrementPercent();
	angleincrement = angleincrement * 10;
	if (isRobotTurn_CCW())
	{
		if (angle < (FULL_ANGLE_VALUE - angleincrement))
		{
			angle += angleincrement;
		}
		else
		{
			angle = 0;
		}
	}
	else if (isRobotTurn_CW())
	{
		if (angle > (angleincrement))
		{
			angle -= angleincrement;
		}
		else
		{
			angle = 360;
		}
	}
	Sleep(50);
	return angle;

}


double calcAngleIncrementPercent(void)
{
	double percent = rightMotorPWMValue();
	percent = percent / 255;

	return percent;
}
#endif