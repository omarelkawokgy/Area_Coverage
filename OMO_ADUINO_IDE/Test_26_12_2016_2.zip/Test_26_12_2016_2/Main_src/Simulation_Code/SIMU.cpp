#include "..\Project_Path.h"
#include "SIMU.h"
#include "PhysRoom.h"
#include RELATIVE_PATH(CONF.h)

#ifdef ENABLE_SIMULATION
#include "SerialObj.h"
#include "PinMODE.h"
#include "PhysCompass.h"
#include "PhysRoom.h"
#include <iostream>
using namespace std;

/*----------------------------- Arduino Functions ------------------------*/
float atan2(uint16 y, uint16 x)
{
	float DegreeAngle = updateCompassValue();
	return (DegreeAngle * CONVERT_FROM_DEG_TO_RAD);
}



/*--------------Interrupt-----------------*/
void attachInterrupt(uint8 numberOfInterrupt, void(*func)(), uint8 type)
{

}

void detachInterrupt(uint8 pin)
{

}

#endif

