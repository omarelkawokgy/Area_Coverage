#ifndef ULS_H
#define ULS_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION

#define CM_TO_MICRO_SECONDS(X) (X * 29.4118 * 2)

bool pulseOccuredLeft(bool pulseReadFlag);

bool pulseOccuredRight(bool pulseReadFlag);

uint64 pulseIn(uint8 pin, bool flag);

#endif
#endif