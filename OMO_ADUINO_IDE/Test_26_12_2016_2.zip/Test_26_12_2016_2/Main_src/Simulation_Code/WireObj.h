#ifndef WIREOBJ_H
#define WIREOBJ_H
#include "..\Project_Path.h"
#include RELATIVE_PATH(types.h)
#include RELATIVE_PATH(CONF.h)
#ifdef ENABLE_SIMULATION

class WireI2C
{
public:
	WireI2C();
	~WireI2C();

	void beginTransmission(int address);
	void write(int numberOfRegister);
	void endTransmission(void);
	uint8 read();
	void requestFrom(int address, const int reg);
	uint8 available();
};
#endif
#endif