#include "SerialObj.h"
#ifdef ENABLE_SIMULATION
#include <iostream>
using namespace std;

/*----------------------------------Serial--------------------------------*/
SerialCom Serial = SerialCom();

SerialCom::SerialCom(){}
SerialCom::~SerialCom(){}

void SerialCom::begin(int speed){}
void SerialCom::print(int number)
{
	cout << number;
}

void SerialCom::println(int number)
{
	//cout << number << endl;
	printf("%d\n",number);
}

void SerialCom::print(int number, int type)
{
	if (type == HEX)
	{
		cout << hex << number;
	}
}

void SerialCom::println(int number, int type)
{
	if (type == HEX)
	{
		cout << hex << number << endl;
	}
}

void SerialCom::print(char* string)
{
	cout << string;
}

void SerialCom::println(char* string)
{
	cout << string << endl;
}

void SerialCom::print(char character)
{
	cout << character;
}

void SerialCom::println(char character)
{
	cout << character << endl;
}

void SerialCom::println(void)
{
	cout << endl;
}

void SerialCom::println(double num)
{
	cout << num << endl;
}

void SerialCom::print(double num)
{
	cout << num;
}
#endif