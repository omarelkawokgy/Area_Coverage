#include "Project_Path.h"
#include RELATIVE_PATH(MOVH.h)
#include RELATIVE_PATH(ERRH.h)
#include RELATIVE_PATH(COMH.h)
#include RELATIVE_PATH(Main_Func_1.h)
#include SIMULATION_PATH(SIMU.h)
#undef PROJECT_PATH_H

MOVE::MOVE()
{
	leftMotor.assignMotorID(LEFT_MOTOR);
	rightMotor.assignMotorID(RIGHT_MOTOR);
}

MOVE& MOVE::getInstance(void)
{
	static MOVE movementHandler;
	return movementHandler;
}

positionHeadingHandler& MOVE::getPosition(void)
{
	return position;
}

return_type MOVE::UpdatePosition(RobotPos* robposition, Heading heading, uint8 Direction)
{
	return_type ret = RET_NOT_OK;
	if (heading != INVALID_DIRECTION)
	{
		if (Direction == FORWARD)
		{
			if (heading == NORTH)
			{
				if (robposition->Y_pos != 0)
				{
					robposition->Y_pos--;
				}
				ret = RET_OK;
			}
			else if (heading == SOUTH)
			{
				robposition->Y_pos++;
				ret = RET_OK;
			}
			else if (heading == WEST)
			{
				if (robposition->X_pos != 0)
				{
					robposition->X_pos--;
				}
				ret = RET_OK;
			}
			else if (heading == EAST)
			{
				robposition->X_pos++;
				ret = RET_OK;
			}
			else
			{
				ret = RET_NOT_OK;
				ERRH::Error_logErrorClass(ERROR_MOVE_MOVEFORWARD_FAIL);
			}
		} 
		else if (Direction == BACKWARD)
		{
			if (heading == NORTH)
			{
				robposition->Y_pos++;
				ret = RET_OK;
			}
			else if (heading == SOUTH)
			{
				if (robposition->Y_pos != 0)
				{
					robposition->Y_pos--;
				}
				ret = RET_OK;
			}
			else if (heading == WEST)
			{
				robposition->X_pos++;
				ret = RET_OK;
			}
			else if (heading == EAST)
			{
				if (robposition->X_pos != 0)
				{
					robposition->X_pos--;
				}
				ret = RET_OK;
			}
			else
			{
				ret = RET_NOT_OK;
				ERRH::Error_logErrorClass(ERROR_MOVE_MOVEBACKWARD_FAIL);
			}
		}
	}
	return ret;
}

return_type MOVE::MoveForward(Heading heading)
{
	return_type Error_Check = RET_NOT_OK;
	if (BumperHit == FALSE)
	{
		/*simulation change*/
		//MOVE::MoveForwardStep(MOVE::getPosition(), heading);
		MOVE::MoveForwardStep(position, heading);
		Error_Check = RET_OK;
	}
	else
	{
		MOVE::MoveStop();
		ERRH::Error_logErrorClass(ERROR_MOVE_MOVEFORWARD_FAIL);
	}
	return Error_Check;
}

return_type MOVE::MoveBackward(Heading heading)
{
	return_type Error_Check = RET_NOT_OK; 

	rightMotor.backward();
	leftMotor.backward();
	return Error_Check = RET_OK;
}

void MOVE::MoveStop(positionHeadingHandler& rob)
{
	Serial.println("Stop");
	leftMotor.stop();
	rightMotor.stop();
}

void MOVE::MoveTurn_CW(positionHeadingHandler& rob, uint16 TargetAngle)
{
	Serial.println("CW");
	RobotPos robPosition = rob.GetRobotPosition();
	uint64 timer = UINT_SNA;
	uint64 timer_comparator = UINT_SNA;

	double PID_error = 0;

	robPosition.theta = rob.getCompass().ReadRawData();
	timer = millis();
	while (((int)robPosition.theta < ((int)TargetAngle - ALLOWED_ANGLE_ERROR)) || (robPosition.theta > (TargetAngle + ALLOWED_ANGLE_ERROR)))
	{
		timer_comparator = millis();
		if (timer_comparator >= (timer + (TIME_OF_TURN_SECONDS)))
		{
			Serial.println("too much time spent in spinning");
			break;
		}
		robPosition.theta = rob.getCompass().ReadRawData();

		PID_error = robPosition.theta - TargetAngle;
		if ((int)PID_error < 0)
		{
			PID_error = (robPosition.theta + 360) - TargetAngle;
		}

		PID_error = PID_error / MAX_TURN_ANGLE;
		PID_error *= FULL_PERCENT;

		if (PID_error > HIGH_PWM)
		{
			PID_error = HIGH_PWM;
		}
		else if (PID_error < MIN_PWM_VALUE)
		{
			PID_error = MIN_PWM_VALUE;
		}

		rightMotor.backward(PID_error);
		leftMotor.forward(PID_error);
	}
	MoveStop();
	rob.SetPosition(robPosition);
}

void MOVE::MoveTurn_CCW(positionHeadingHandler& rob, uint16 TargetAngle)
{
#define TAWO_P 0.2
#define TAWO_D 2.5
#define TAWO_I 0.004

	Serial.println("CCW");
	RobotPos robPosition = rob.GetRobotPosition();
	uint64 timer = UINT_SNA;
	uint64 timer_comparator = UINT_SNA;

	double PID_error = 0;

	robPosition.theta = rob.getCompass().ReadRawData();
	timer = millis();
	while (((int)robPosition.theta < ((int)TargetAngle - ALLOWED_ANGLE_ERROR)) || (robPosition.theta >(TargetAngle + ALLOWED_ANGLE_ERROR)))
	{
		/*TODO: timer in case angle didnt reach*/
		timer_comparator = millis();
		if (timer_comparator >= (timer + (TIME_OF_TURN_SECONDS)))
		{
			Serial.println("too much time spent in spinning");
			break;
		}
		robPosition.theta = rob.getCompass().ReadRawData();

		PID_error = TargetAngle - robPosition.theta;
		if ((int)PID_error < 0)
		{
			PID_error = (TargetAngle + 360) - robPosition.theta;
		}
		
		PID_error = PID_error / MAX_TURN_ANGLE;
		PID_error *= FULL_PERCENT;

		if (PID_error > HIGH_PWM)
		{
			PID_error = HIGH_PWM;
		}
		else if (PID_error < MIN_PWM_VALUE)
		{
			PID_error = MIN_PWM_VALUE;
		}

		rightMotor.forward((int)PID_error);
		leftMotor.backward((int)PID_error);
	}
	MoveStop();
	rob.SetPosition(robPosition);
}

void MOVE::CalcSingleStep(positionHeadingHandler& positionOfRobot, Heading headingRequest)
{
	uint16 current_encoder_status = UINT_SNA;
	uint16 counter_ticks = UINT_SNA;
	uint64 currentTime = UINT_SNA;
	uint8 numberOfFixes = UINT_SNA;

	rightMotor.forward();
	leftMotor.forward();

	currentTime = millis();
	while (((counter_ticks < ROBOT_SINGLE_STEP) && (BumperHit == FALSE))
			&& ((millis() - currentTime) < FORWARD_SINGLE_STEP_TIMEOUT_VALUE))
	{
		current_encoder_status = positionOfRobot.getRightEncoder().read_right_encoder_ticks();

		while ((CHECK_IF_HIGH(current_encoder_status)) && (BumperHit == FALSE)
				&& ((millis() - currentTime) < FORWARD_SINGLE_STEP_TIMEOUT_VALUE))
		{
			current_encoder_status = positionOfRobot.getRightEncoder().read_right_encoder_ticks();
			if (CHECK_IF_LOW(current_encoder_status))
			{
				counter_ticks++;
			}
		}

		if(MOVE::fixCurrentHeading(positionOfRobot, headingRequest))
		{
	//		numberOfFixes++;
			currentTime = millis();
		}

		rightMotor.forward();
		leftMotor.forward();

		if(numberOfFixes >= MAX_NUMBER_OF_DIRECTION_FIXES)
		{
			break;
		}
	}
	if (BumperHit == TRUE)
	{
		leftMotor.stop();
		rightMotor.stop();
	}

	if (counter_ticks < ROBOT_SINGLE_STEP)
	{
		ERRH::Error_logErrorClass(WARNING_ENCOD_NOT_COMPLETE_STEP);
	}
}

void MOVE::MoveForwardStep(positionHeadingHandler& positionOfRobot, Heading headingRequest)
{
	/*TODO: handle crashing before continuing this step*/
	/*the robot will stop as it hits an object to need to handle it here*/
	RobotPos robposition;
	return_type Error_Check = RET_NOT_OK;

	  MOVE::CalcSingleStep(positionOfRobot, headingRequest);
	  robposition = positionOfRobot.GetRobotPosition();
		/*TODO: timer in case counter didnt reach*/
	Error_Check = UpdatePosition(&robposition, headingRequest, FORWARD);
	if (Error_Check == RET_OK)
	{
			positionOfRobot.SetPosition(robposition);
	}
	else
	{
		ERRH::Error_logErrorClass(ERROR_MOVE_UPDATE_POSITION);
	}
}

void MOVE::UTurnRight(positionHeadingHandler& cleaner, Heading HeadingRequest)
{
	switch (HeadingRequest)
	{
	case NORTH:
		MOVE::MoveTurn_CW(cleaner, EAST_VALUE);
		HeadingRequest = EAST;
		MOVE::MoveForwardStep(getPosition(), HeadingRequest);
		BumperHit = FALSE;
		MOVE::MoveTurn_CW(getPosition(), SOUTH_VALUE);
		break;
	case WEST:
		MOVE::MoveTurn_CW(getPosition(), NORTH_VALUE);
		HeadingRequest = NORTH;
		MOVE::MoveForwardStep(getPosition(), HeadingRequest);
		BumperHit = FALSE;
		MOVE::MoveTurn_CW(getPosition(), EAST_VALUE);
		break;
	case SOUTH:
		MOVE::MoveTurn_CW(getPosition(), WEST_VALUE);
		HeadingRequest = WEST;
		MOVE::MoveForwardStep(getPosition(), HeadingRequest);
		BumperHit = FALSE;
		MOVE::MoveTurn_CW(getPosition(), NORTH_VALUE);
		break;
	case EAST:
		MOVE::MoveTurn_CW(getPosition(), SOUTH_VALUE);
		HeadingRequest = SOUTH;
		MOVE::MoveForwardStep(getPosition(), HeadingRequest);
		BumperHit = FALSE;
		MOVE::MoveTurn_CW(getPosition(), WEST_VALUE);
		break;
	default:
		/*TODO: heading is invalid*/
		ERRH::Error_logErrorClass(ERROR_MOVE_UT_RIGHT_DEFAULT_CASE);
		MOVE::MoveStop(getPosition());
		break;
	}
}

void MOVE::UTurnLeft(positionHeadingHandler& cleaner, Heading RobCurrentHeading)
{
	switch (RobCurrentHeading)
	{
	case NORTH:
		MOVE::MoveTurn_CCW(getPosition(), WEST_VALUE);
		RobCurrentHeading = WEST;
		MOVE::MoveForwardStep(getPosition(), RobCurrentHeading);
		BumperHit = FALSE;
		MOVE::MoveTurn_CCW(getPosition(), SOUTH_VALUE);
		break;
	case WEST:
		MOVE::MoveTurn_CCW(getPosition(), SOUTH_VALUE);
		RobCurrentHeading = SOUTH;
		MOVE::MoveForwardStep(getPosition(), RobCurrentHeading);
		BumperHit = FALSE;
		MOVE::MoveTurn_CCW(getPosition(), EAST_VALUE);
		break;
	case SOUTH:
		MOVE::MoveTurn_CCW(getPosition(), EAST_VALUE);
		RobCurrentHeading = EAST;
		MOVE::MoveForwardStep(getPosition(), RobCurrentHeading);
		BumperHit = FALSE;
		MOVE::MoveTurn_CCW(getPosition(), NORTH_VALUE);
		break;
	case EAST:
		MOVE::MoveTurn_CCW(getPosition(), NORTH_VALUE);
		RobCurrentHeading = NORTH;
		MOVE::MoveForwardStep(getPosition(), RobCurrentHeading);
		BumperHit = FALSE;
		MOVE::MoveTurn_CCW(getPosition(), WEST_VALUE);
		break;
	default:
		/*TODO: heading is invalid*/
		ERRH::Error_logErrorClass(ERROR_MOVE_UT_LEFT_DEFAULT_CASE);
		MOVE::MoveStop(getPosition());
		break;
	}
}

void MOVE::UTurn(positionHeadingHandler& cleaner, Heading RobCurrentHeading)
{
	switch (RobCurrentHeading)
	{
	case NORTH:
		MOVE::MoveTurn_CW(getPosition(), SOUTH_VALUE);
		break;
	case WEST:
		MOVE::MoveTurn_CW(getPosition(), EAST_VALUE);
		break;
	case SOUTH:
		MOVE::MoveTurn_CW(getPosition(), NORTH_VALUE);
		break;
	case EAST:
		MOVE::MoveTurn_CW(getPosition(), WEST_VALUE);
		break;
	default:
		/*TODO: heading is invalid*/
		ERRH::Error_logErrorClass(ERROR_MOVE_UT_DEFAULT_CASE);
		MOVE::MoveStop();
		break;
	}
}

void MOVE::MoveTurn_CW(void)
{
	leftMotor.forward();
	rightMotor.backward();
}

void MOVE::MoveTurn_CCW(void)
{
	leftMotor.backward();
	rightMotor.forward();
}

void MOVE::MoveStop(void)
{
	Serial.println("Stop");
	leftMotor.stop();
	rightMotor.stop();
}

void MOVE::MoveBackward(void)
{
	leftMotor.backward();
	rightMotor.backward();
}

bool MOVE::fixCurrentHeading(positionHeadingHandler& cleaner, Heading headingRequest)
{
#undef OLD_FIX_HEADING
#ifdef OLD_FIX_HEADING
	Heading robotCurrentHeading = INVALID_DIRECTION;
	robotCurrentHeading = cleaner.GetRobotHeading();
	int16 tempRequestedAngle = cleaner.ReadRawData();
	bool validDirectionHeadingFlag = FALSE;

	if(headingRequest != robotCurrentHeading)
	{
		if(headingRequest == NORTH)
		{
			if(tempRequestedAngle < NORTH_RIGHT_RANGE)
			{
				MOVE::MoveTurn_CCW(cleaner, NORTH_VALUE);
			}
			else if (tempRequestedAngle > NORTH_LEFT_RANGE)
			{
				MOVE::MoveTurn_CW(cleaner, NORTH_VALUE);
			}
		}
		else if(headingRequest == SOUTH)
		{
			if ((tempRequestedAngle < SOUTH_RIGHT_RANGE) && (tempRequestedAngle > WEST_LEFT_RANGE))
			{
				MOVE::MoveTurn_CCW(cleaner, SOUTH_VALUE);
			}
			else if ((tempRequestedAngle > SOUTH_LEFT_RANGE) && (tempRequestedAngle < EAST_RIGHT_RANGE))
			{
				MOVE::MoveTurn_CW(cleaner, SOUTH_VALUE);
			}
		}
		else if(headingRequest == EAST)
		{
			if((tempRequestedAngle > EAST_LEFT_RANGE))
			{
				MOVE::MoveTurn_CW(cleaner, EAST_VALUE);
			}
			else if ((tempRequestedAngle < EAST_RIGHT_RANGE))
			{
				MOVE::MoveTurn_CCW(cleaner, EAST_VALUE);
			}
		}
		else if(headingRequest == WEST)
		{
			if((tempRequestedAngle < WEST_RIGHT_RANGE))
			{
				MOVE::MoveTurn_CCW(cleaner, WEST_VALUE);
			}
			else if ((tempRequestedAngle > WEST_LEFT_RANGE))
			{
				MOVE::MoveTurn_CW(cleaner, WEST_VALUE);
			}
		}
		MoveStop();
		validDirectionHeadingFlag = TRUE;
	}
return validDirectionHeadingFlag;
#else
	Heading robotCurrentHeading = INVALID_DIRECTION;
	robotCurrentHeading = cleaner.GetRobotHeading();
	int16 tempCurrentAngle = 0;
	int16 targetAngle = 500;
	int16 angle_CCW_Error = 0;
	int16 angle_CW_Error = 0;
	bool validDirectionHeadingFlag = FALSE;

	if (headingRequest != robotCurrentHeading)
	{
		Serial.print("headingRequest: ");
		Serial.println(headingRequest);

		Serial.print("robotCurrentHeading: ");
		Serial.println(robotCurrentHeading);

		tempCurrentAngle = cleaner.ReadRawData();
		{
			switch (headingRequest)
			{
			case NORTH:
				targetAngle = NORTH_VALUE;
				break;
			case EAST:
				targetAngle = EAST_VALUE;
				break;
			case SOUTH:
				targetAngle = SOUTH_VALUE;
				break;
			case WEST:
				targetAngle = WEST_VALUE;
				break;
			default:
				/*invalid request*/
				break;
			}

			angle_CCW_Error = targetAngle - tempCurrentAngle;
			if (angle_CCW_Error < 0)
			{
				angle_CCW_Error = (targetAngle + 360) - tempCurrentAngle;
			}

			angle_CW_Error = tempCurrentAngle - targetAngle;
			if (angle_CW_Error < 0)
			{
				angle_CW_Error = (tempCurrentAngle + 360) - targetAngle;
			}
		}

		if (angle_CCW_Error < angle_CW_Error)
		{
			MOVE::MoveTurn_CCW(cleaner, targetAngle);
		}
		else if (angle_CW_Error < angle_CCW_Error)
		{
			MOVE::MoveTurn_CW(cleaner, targetAngle);
		}

		validDirectionHeadingFlag = TRUE;
	}
	return validDirectionHeadingFlag;
#endif
}
