#ifndef COMH_H
#define COMH_H
#include "types.h"
#include "CONF.h"
#ifndef ENABLE_SIMULATION
#include <Wire.h>
#endif

 /*values of directions*/
extern int16 NORTH_VALUE;
extern int16 WEST_VALUE;
extern int16 SOUTH_VALUE;
extern int16 EAST_VALUE;

class Comp
{
private:

	friend class positionHeadingHandler;
	double compassKalmanFilter1D(double* Z);
public:
	Comp();
	static Comp& getInstance(void);

	void InitializeDirections(void);

	Heading ReadComp(void);
	
	int16 ReadRawData(void);

	static Heading calcRobotHeading(int16 angle);

	return_type CheckConnection(void);

};
#endif
